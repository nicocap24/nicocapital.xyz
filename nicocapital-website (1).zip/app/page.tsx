import { Hero } from "@/components/hero"
import { Projects } from "@/components/projects"
import { InvestorsSection } from "@/components/investors-section"
import { SwapSection } from "@/components/swap-section"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <Projects />
      <InvestorsSection />
      <SwapSection />
      <Footer />
    </div>
  )
}
