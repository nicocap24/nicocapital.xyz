import type React from "react"
export interface Project {
  id: string
  name: string
  description: string
  status: "Live" | "Beta" | "Development"
  investment: string
  returns: string
  category: string
  color: string
}

export interface Investor {
  name: string
  displayName: string
  icon: React.ReactNode
}

export interface SocialLink {
  name: string
  url: string
  icon: React.ReactNode
  title: string
}
