"use client"

import { useState, useEffect, useCallback } from "react"

interface UseWalletReturn {
  account: string | null
  isConnecting: boolean
  connectWallet: () => Promise<void>
  disconnectWallet: () => void
  formatAddress: (address: string) => string
}

export function useWallet(): UseWalletReturn {
  const [account, setAccount] = useState<string | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)

  const checkExistingConnection = useCallback(async () => {
    if (typeof window.ethereum !== "undefined") {
      try {
        const accounts = await window.ethereum.request({ method: "eth_accounts" })
        if (accounts.length > 0) {
          setAccount(accounts[0])
        }
      } catch (error) {
        // Silently handle errors
      }
    }
  }, [])

  const connectWallet = useCallback(async () => {
    if (typeof window.ethereum === "undefined") {
      alert("Please install MetaMask to connect your wallet")
      return
    }

    setIsConnecting(true)

    try {
      const accounts = await window.ethereum.request({
        method: "eth_requestAccounts",
      })
      if (accounts.length > 0) {
        setAccount(accounts[0])
      }
    } catch (error: any) {
      if (error.code === 4001 || error.code === -32002) {
        // User rejected or request pending - silent
        return
      } else {
        console.error("Unexpected wallet error:", error)
      }
    } finally {
      setIsConnecting(false)
    }
  }, [])

  const disconnectWallet = useCallback(() => {
    setAccount(null)
  }, [])

  const formatAddress = useCallback((address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`
  }, [])

  useEffect(() => {
    checkExistingConnection()

    if (typeof window.ethereum !== "undefined") {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length > 0) {
          setAccount(accounts[0])
        } else {
          setAccount(null)
        }
      }

      const handleDisconnect = () => {
        setAccount(null)
      }

      window.ethereum.on("accountsChanged", handleAccountsChanged)
      window.ethereum.on("disconnect", handleDisconnect)

      return () => {
        window.ethereum.removeListener("accountsChanged", handleAccountsChanged)
        window.ethereum.removeListener("disconnect", handleDisconnect)
      }
    }
  }, [checkExistingConnection])

  return {
    account,
    isConnecting,
    connectWallet,
    disconnectWallet,
    formatAddress,
  }
}
