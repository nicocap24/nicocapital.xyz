"use client"

import { Button } from "@/components/ui/button"
import Image from "next/image"
import { SITE_CONFIG } from "@/constants/config"

const scrollToSwap = () => {
  document.getElementById("swap")?.scrollIntoView({ behavior: "smooth" })
}

export function Hero() {
  return (
    <section className="pt-32 pb-20 px-4 bg-white">
      <div className="container mx-auto text-center">
        <div className="max-w-4xl mx-auto">
          {/* Avatar Image */}
          <div className="mb-8 flex justify-center">
            <div className="relative w-32 h-32 rounded-full overflow-hidden border-4 border-green-500 shadow-lg">
              <Image
                src={SITE_CONFIG.avatar || "/placeholder.svg"}
                alt="nicocapital avatar"
                fill
                className="object-cover"
              />
            </div>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold text-gray-900 mb-6">{SITE_CONFIG.title}</h1>
          <p className="text-xl text-gray-700 mb-4 max-w-2xl mx-auto font-medium">{SITE_CONFIG.description}</p>

          <div className="flex justify-center">
            <Button
              size="lg"
              className="bg-green-500 hover:bg-green-600 text-white px-8 text-xl"
              onClick={scrollToSwap}
            >
              Invest
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
