const investors = [
  {
    name: "Alóz Crypto",
    logo: "/images/investors-logos.png",
    position: "0 0",
    width: "120px",
    height: "60px",
  },
  {
    name: "Variant",
    logo: "/images/investors-logos.png",
    position: "-140px 0",
    width: "120px",
    height: "60px",
  },
  {
    name: "Coinbase Ventures",
    logo: "/images/investors-logos.png",
    position: "-280px 0",
    width: "180px",
    height: "60px",
  },
  {
    name: "Founders Fund",
    logo: "/images/investors-logos.png",
    position: "-480px 0",
    width: "140px",
    height: "60px",
  },
  {
    name: "Paradigm",
    logo: "/images/investors-logos.png",
    position: "-640px 0",
    width: "140px",
    height: "60px",
  },
]

export function InvestorsSection() {
  return (
    <section className="py-20 px-4 bg-white border-t border-gray-100">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">List of investors WHO HAVEN'T INVESTED IN US:</h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Some of the most prominent crypto investors and funds... yet.
          </p>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-12 md:gap-16">
          <div className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100">
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600 mb-2">alóz</div>
              <div className="text-sm text-gray-500">crypto</div>
            </div>
          </div>

          <div className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600 mb-2">✚ variant</div>
            </div>
          </div>

          <div className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600 mb-2">coinbase</div>
              <div className="text-sm text-gray-500">Ventures</div>
            </div>
          </div>

          <div className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100">
            <div className="text-center">
              <div className="flex items-center gap-2 mb-2">
                <div className="w-3 h-6 bg-red-500"></div>
                <div className="w-3 h-6 bg-green-500"></div>
                <span className="text-xl font-bold text-gray-900 ml-2">FOUNDERS FUND</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100">
            <div className="text-center">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-green-500 transform rotate-45 relative">
                  <div className="absolute inset-1 bg-white transform -rotate-45"></div>
                </div>
                <span className="text-2xl font-bold text-gray-900">Paradigm</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-500 text-sm italic">"We're still waiting for their calls... 📞"</p>
        </div>
      </div>
    </section>
  )
}
