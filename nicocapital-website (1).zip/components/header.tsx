"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { WalletConnect } from "@/components/wallet-connect"
import { BrandLogo } from "@/components/ui/brand-logo"
import { Menu, X } from "lucide-react"

const NAVIGATION_LINKS = [
  { href: "#projects", label: "Projects" },
  { href: "#swap", label: "$CAPITAL" },
] as const

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <BrandLogo />

          <nav className="hidden md:flex items-center space-x-8">
            {NAVIGATION_LINKS.map((link) => (
              <a key={link.href} href={link.href} className="text-gray-700 hover:text-gray-900 transition-colors">
                {link.label}
              </a>
            ))}
            <WalletConnect />
          </nav>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden text-gray-900"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X /> : <Menu />}
          </Button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-gray-200">
            <nav className="flex flex-col space-y-4 mt-4">
              {NAVIGATION_LINKS.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="text-gray-700 hover:text-gray-900 transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <WalletConnect />
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
