import { BrandLogo } from "@/components/ui/brand-logo"
import { SocialLinks } from "@/components/ui/social-links"

export function Footer() {
  return (
    <footer className="py-12 px-4 border-t border-gray-200 bg-white">
      <div className="container mx-auto">
        <div className="flex flex-col items-center justify-center text-center">
          <BrandLogo className="text-2xl font-bold text-gray-900 mb-6" />

          <div className="mb-8">
            <SocialLinks />
          </div>

          <div className="pt-8 border-t border-gray-200">
            <p className="text-gray-600 text-sm">© 2024 nicocapital. All rights reserved. Investment involves risk.</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
