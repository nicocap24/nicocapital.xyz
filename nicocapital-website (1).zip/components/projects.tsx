"use client"

import { ProjectCircle } from "@/components/ui/project-circle"
import { PROJECTS, PORTFOLIO_STATS } from "@/constants/projects"

export function Projects() {
  return (
    <section id="projects" className="py-20 px-4 bg-gray-50 overflow-hidden">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Investment Projects</h2>
          <p className="text-gray-700 text-lg max-w-2xl mx-auto">
            Explore the innovative projects I've invested in and created. Each represents a unique opportunity in the
            evolving crypto landscape.
          </p>
        </div>

        {/* Horizontal scrolling container */}
        <div className="relative">
          <div className="flex animate-scroll space-x-8 w-max">
            {/* First set of projects */}
            {PROJECTS.map((project) => (
              <div key={`first-${project.id}`} className="flex-shrink-0">
                <ProjectCircle project={project} />
              </div>
            ))}
            {/* Duplicate set for seamless loop */}
            {PROJECTS.map((project) => (
              <div key={`second-${project.id}`} className="flex-shrink-0">
                <ProjectCircle project={project} />
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 text-sm">
            Total Portfolio Value:{" "}
            <span className="font-bold text-green-500">{PORTFOLIO_STATS.totalInvestment} invested</span> •
            <span className="font-bold text-green-500"> Average Return: {PORTFOLIO_STATS.averageReturn}</span>
          </p>
        </div>
      </div>

      <style jsx>{`
        @keyframes scroll {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-50%);
          }
        }
        
        .animate-scroll {
          animation: scroll 30s linear infinite;
        }
        
        .animate-scroll:hover {
          animation-play-state: paused;
        }
      `}</style>
    </section>
  )
}
