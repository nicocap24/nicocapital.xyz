import { Card, CardContent } from "@/components/ui/card"
import { TrendingUp } from "lucide-react"
import type { Project } from "@/types"

interface ProjectCircleProps {
  project: Project
}

export function ProjectCircle({ project }: ProjectCircleProps) {
  const getStatusColor = (status: Project["status"]) => {
    switch (status) {
      case "Live":
        return "bg-green-100 text-green-700"
      case "Beta":
        return "bg-yellow-100 text-yellow-700"
      case "Development":
        return "bg-blue-100 text-blue-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <div className="group cursor-pointer">
      <div
        className={`w-64 h-64 rounded-full ${project.color} p-1 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}
      >
        <Card className="w-full h-full rounded-full bg-white/95 backdrop-blur-sm border-0 flex items-center justify-center">
          <CardContent className="text-center p-6">
            <div className="mb-3">
              <h3 className="text-lg font-bold text-gray-900 mb-1">{project.name}</h3>
              <span className={`text-xs px-2 py-1 rounded-full ${getStatusColor(project.status)}`}>
                {project.status}
              </span>
            </div>

            <p className="text-sm text-gray-600 mb-3 line-clamp-3">{project.description}</p>

            <div className="space-y-2">
              <div className="flex items-center justify-center gap-2">
                <span className="text-sm text-gray-500">Investment:</span>
                <span className="font-semibold text-gray-900">{project.investment}</span>
              </div>

              <div className="flex items-center justify-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-500" />
                <span className="font-bold text-green-500">{project.returns}</span>
              </div>
            </div>

            <div className="mt-3">
              <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">{project.category}</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
