interface BrandLogoProps {
  className?: string
}

export function BrandLogo({ className = "text-2xl font-bold text-gray-900" }: BrandLogoProps) {
  return (
    <div className={className}>
      nico<span className="text-green-500">capital</span>
    </div>
  )
}
