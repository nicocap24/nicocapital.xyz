import { SOCIAL_LINKS } from "@/constants/social-links"

export function SocialLinks() {
  return (
    <div className="flex items-center justify-center space-x-6">
      {SOCIAL_LINKS.map((link) => (
        <a
          key={link.name}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-gray-600 hover:text-gray-900 transition-colors"
          title={link.title}
        >
          {link.icon}
        </a>
      ))}
    </div>
  )
}
