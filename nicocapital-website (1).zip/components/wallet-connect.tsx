"use client"

import { Button } from "@/components/ui/button"
import { Wallet } from "lucide-react"
import { useWallet } from "@/hooks/use-wallet"

declare global {
  interface Window {
    ethereum?: any
  }
}

export function WalletConnect() {
  const { account, isConnecting, connectWallet, disconnectWallet, formatAddress } = useWallet()

  return (
    <div>
      {account ? (
        <Button
          variant="outline"
          onClick={disconnectWallet}
          className="border-green-500 text-green-500 hover:bg-green-500 hover:text-white"
        >
          <Wallet className="mr-2 h-4 w-4" />
          {formatAddress(account)}
        </Button>
      ) : (
        <Button onClick={connectWallet} disabled={isConnecting} className="bg-green-500 hover:bg-green-600">
          <Wallet className="mr-2 h-4 w-4" />
          {isConnecting ? "Connecting..." : "Connect Wallet"}
        </Button>
      )}
    </div>
  )
}
