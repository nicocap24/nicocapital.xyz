"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowDownUp, Copy, ExternalLink } from "lucide-react"

const CAPITAL_CONTRACT = "0x25e1e53d1b3c22dd94dfbf3c00671a78a3bbb585"

export function SwapSection() {
  const [fromAmount, setFromAmount] = useState("")
  const [toAmount, setToAmount] = useState("")

  const copyContract = () => {
    navigator.clipboard.writeText(CAPITAL_CONTRACT)
  }

  const handleSwap = () => {
    // This would integrate with a DEX like Uniswap
    console.log("Swap initiated:", { fromAmount, toAmount })
  }

  return (
    <section id="swap" className="py-20 px-4 bg-white">
      <div className="container mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Get $CAPITAL Token</h2>
          <p className="text-gray-700 text-lg max-w-2xl mx-auto">
            Invest alongside me by acquiring $CAPITAL tokens. Each token represents a share in my investment strategy.
          </p>
        </div>

        <div className="max-w-md mx-auto">
          <Card className="bg-white border-gray-200 shadow-lg">
            <CardHeader>
              <CardTitle className="text-gray-900 text-center">Swap for $CAPITAL</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="from-amount" className="text-gray-700">
                  From (ETH)
                </Label>
                <Input
                  id="from-amount"
                  type="number"
                  placeholder="0.0"
                  value={fromAmount}
                  onChange={(e) => setFromAmount(e.target.value)}
                  className="bg-gray-50 border-gray-300 text-gray-900 placeholder:text-gray-500"
                />
              </div>

              <div className="flex justify-center">
                <Button variant="ghost" size="icon" className="text-gray-600 hover:text-gray-900">
                  <ArrowDownUp className="h-4 w-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor="to-amount" className="text-gray-700">
                  To ($CAPITAL)
                </Label>
                <Input
                  id="to-amount"
                  type="number"
                  placeholder="0.0"
                  value={toAmount}
                  onChange={(e) => setToAmount(e.target.value)}
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50"
                />
              </div>

              <Button onClick={handleSwap} className="w-full bg-green-500 hover:bg-green-600" disabled={!fromAmount}>
                Swap
              </Button>

              <div className="pt-4 border-t border-white/10">
                <Label className="text-gray-700 text-sm">Contract Address</Label>
                <div className="flex items-center gap-2 mt-1">
                  <code className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded flex-1 truncate">
                    {CAPITAL_CONTRACT}
                  </code>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={copyContract}
                    className="h-8 w-8 text-white/60 hover:text-white"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-white/60 hover:text-white"
                    onClick={() => window.open(`https://etherscan.io/address/${CAPITAL_CONTRACT}`, "_blank")}
                  >
                    <ExternalLink className="h-3 w-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
