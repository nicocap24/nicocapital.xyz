import type { Project } from "@/types"

export const PROJECTS: Project[] = [
  {
    id: "defi-yield-optimizer",
    name: "DeFi Yield Optimizer",
    description: "Automated yield farming protocol that maximizes returns across multiple DeFi platforms.",
    status: "Live",
    investment: "$50K",
    returns: "+127%",
    category: "DeFi",
    color: "bg-blue-500",
  },
  {
    id: "nft-marketplace",
    name: "NFT Marketplace",
    description: "Next-generation NFT marketplace with advanced analytics and creator tools.",
    status: "Beta",
    investment: "$75K",
    returns: "+89%",
    category: "NFT",
    color: "bg-purple-500",
  },
  {
    id: "cross-chain-bridge",
    name: "Cross-Chain Bridge",
    description: "Secure and efficient bridge for transferring assets between different blockchains.",
    status: "Development",
    investment: "$100K",
    returns: "TBD",
    category: "Infrastructure",
    color: "bg-green-500",
  },
  {
    id: "ai-trading-bot",
    name: "AI Trading Bot",
    description: "Machine learning-powered trading bot for cryptocurrency markets.",
    status: "Live",
    investment: "$30K",
    returns: "+156%",
    category: "AI/Trading",
    color: "bg-orange-500",
  },
  {
    id: "layer-2-protocol",
    name: "Layer 2 Protocol",
    description: "Scaling solution for Ethereum with ultra-low fees and high throughput.",
    status: "Live",
    investment: "$200K",
    returns: "+234%",
    category: "Infrastructure",
    color: "bg-indigo-500",
  },
  {
    id: "metaverse-platform",
    name: "Metaverse Platform",
    description: "Virtual world platform with integrated DeFi and NFT ecosystems.",
    status: "Beta",
    investment: "$150K",
    returns: "+67%",
    category: "Metaverse",
    color: "bg-pink-500",
  },
]

export const PORTFOLIO_STATS = {
  totalInvestment: "$605K",
  averageReturn: "+128%",
}
