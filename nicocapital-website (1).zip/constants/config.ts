export const SITE_CONFIG = {
  name: "nicocapital",
  title: "Nico Capital.",
  description: "Nico Capital was born on the internet in 2019, as a symbol of fight towards freedom.",
  avatar: "/images/nicocap-avatar.jpg",
  capitalContract: "0x25e1e53d1b3c22dd94dfbf3c00671a78a3bbb585",
  brand: {
    primary: "green-500",
    hover: "green-600",
    light: "green-100",
    dark: "green-700",
  },
} as const
