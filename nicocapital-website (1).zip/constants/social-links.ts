import { Github, Twitter, Linkedin, Mail } from "lucide-react"
import type { SocialLink } from "@/types"

export const SOCIAL_LINKS: SocialLink[] = [
  {
    name: "twitter",
    url: "https://x.com/nicocapital",
    icon: <Twitter className="h-5 w-5" />,
    title: "Twitter",
  },
  {
    name: "farcaster",
    url: "https://farcaster.xyz/nicocapital",
    icon: (
      <div className="w-5 h-5 rounded-full bg-purple-600 flex items-center justify-center">
        <span className="text-white text-xs font-bold">F</span>
      </div>
    ),
    title: "Farcaster",
  },
  {
    name: "github",
    url: "https://github.com/nicocap24",
    icon: <Github className="h-5 w-5" />,
    title: "GitHub",
  },
  {
    name: "linkedin",
    url: "#",
    icon: <Linkedin className="h-5 w-5" />,
    title: "LinkedIn",
  },
  {
    name: "email",
    url: "#",
    icon: <Mail className="h-5 w-5" />,
    title: "Email",
  },
]
